# DLCV 2021Fall Final Project ( Skull Fractracture Detection )

# TEAM: GANOutOfMemory, members: Cheng-Hsuan Hsieh, Hsin-Yin Chi, Yi-Ting Hung, Tsu-Fu Li, Yu-Chin Tsai

# How to run:
	python3 inference.py --source <FOLDER PATH OF A CASE>\
						 --pred_case (IF PREDICT 0/1)\
						 --gates min,con,ens (CHOOSE THE POST-PROCESSING GATES YOU WANT, 0 FOR NO POST-PROCESS)


### inference_utils.py
In the inference_utils.py, there are three hyper-parameters can set
a. MIN_IMGS  (default 5): if case images less than MIN_IMGS, the min gate threshold would be MIN_GATE_THRES_TINY, or the threshold would be MIN_GATE_THRES_MANY
b. MIN_GATE_THRES_TINY (default 1)
c. MIN_GATE_THRES_MANY (default 3)