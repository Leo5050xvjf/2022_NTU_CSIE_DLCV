import torch
import argparse
import numpy as np
from inference_utils import np2img, detect_gates, detect_gates_ens, detect_gates_ens_points, detect_gates_points







def get_model(model_path_1=None, model_path_2=None):
	"""
		Return: model to predict case-lavel label
	"""
	if model_path_1 == None:
		model_path_1 = './ckpt/yolov5s_adamw.pt'
	if model_path_2 == None:
		model_path_2 = './ckpt/yolov5s_sgd.pt'

	model = []
	try:
		model.append(torch.hub.load('ultralytics/yolov5', 'custom', path=model_path_1))
		model.append(torch.hub.load('ultralytics/yolov5', 'custom', path=model_path_2))
	except:
		model.append(torch.hub.load('ultralytics/yolov5', 'custom', path=model_path_1, force_reload=True))
		model.append(torch.hub.load('ultralytics/yolov5', 'custom', path=model_path_2, force_reload=True))

	print('\n[INFO]: scucess to load models')

	return model


def get_model_points(model_path_1=None, model_path_2=None):
	"""
		Return: model to predict bone-frature points
	"""
	if model_path_1 == None:
		model_path_1 = './ckpt/yolov5s_adamw.pt'
	if model_path_2 == None:
		model_path_2 = './ckpt/yolov5s_sgd.pt'

	model = []
	try:
		model.append(torch.hub.load('ultralytics/yolov5', 'custom', path=model_path_1))
		model.append(torch.hub.load('ultralytics/yolov5', 'custom', path=model_path_2))
	except:
		model.append(torch.hub.load('ultralytics/yolov5', 'custom', path=model_path_1, force_reload=True))
		model.append(torch.hub.load('ultralytics/yolov5', 'custom', path=model_path_2, force_reload=True))

	print('\n[INFO]: scucess to load models')

	return model




def predict_case(input, model, gates=['m','c','e'], conf=0.5):
	"""
		input: N * H * W (H=W=512), HU value
		model
		Return: 0 / 1, negetive / positive 
	"""
	model_adamw, model_sgd = model
	model_adamw.conf = conf
	model_sgd.conf = conf
	
	output_adamw = model_adamw(input, size=512).xyxy
	output_sgd= model_sgd(input, size=512).xyxy

	if ('e' in gates) or ('ens' in gates) or ('E' in gates) or ('ENS' in gates):
		case_predict = detect_gates_ens(output_adamw, output_sgd, gates)
	else:
		case_predict = detect_gates(output_adamw, gates)

	return case_predict


def predict_points(input_batch, model_points, gates=['m','c','e'], conf=0.5):
	"""
		input_batch: N * H * W (H=W=512), HU value
		model_points
		Return: [
					[[x1, y1], [x2, y2], ... , [xk, yk]],
					......
					[[x1, y1], [x2, y2], ... , [xk, yk]]
				]
	"""
	model_adamw, model_sgd = model_points
	model_adamw.conf = conf
	model_sgd.conf = conf

	output_adamw = model_adamw(input_batch, size=512).xyxy
	output_sgd= model_sgd(input_batch, size=512).xyxy
	

	if ('e' in gates) or ('ens' in gates) or ('E' in gates) or ('ENS' in gates):
		case_predict = detect_gates_ens_points(output_adamw, output_sgd, gates)
	else:
		case_predict = detect_gates_points(output_adamw, gates)

	return case_predict





def main(args):
	
	if args.pred_case:
		model = get_model(args.model_a, args.model_b)
		imgs = np2img(args.source)
		case_predict = predict_case(imgs, model, args.gates, args.conf)
		case_to_text = 'FRACTURE DETECTED' if case_predict==1 else 'NO FRACTURE DETECTED'
		case = args.source.split('/')[-1]
		print(f'[RESULT]: predict case: {case} \n          --> {case_to_text}\n')

	else:
		model_points = get_model_points(args.model_a, args.model_b)
		imgs = np2img(args.source)
		case_predict = predict_points(imgs, model_points, args.gates, args.conf)
		case = args.source.split('/')[-1]
		print(f'[RESULT]: predict case: {case}\n          --> {case_predict}\n')


def argument():
	parser = argparse.ArgumentParser()

	parser.add_argument('--model_a', default='./ckpt/yolov5s_adamw.pt', type=str)
	parser.add_argument('--model_b', default='./ckpt/yolov5s_sgd.pt', type=str)

	parser.add_argument('--source', default='./data', type=str)
	parser.add_argument('--pred_case', action='store_true')

	parser.add_argument('--gates', default='min,con,ens',type=str)
	parser.add_argument('--conf', default=0.5,type=float)
	args = parser.parse_args()

	if args.gates == '0':
		args.gates = ''
	else:
		args.gates = args.gates.split(',')
	print(f'[INFO]: using gates: {args.gates}\n')

	return args


if __name__ == '__main__':
	args = argument()
	main(args)








