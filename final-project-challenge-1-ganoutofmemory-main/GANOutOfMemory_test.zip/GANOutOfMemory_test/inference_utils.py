import numpy as np
import os
import torch



MIN_IMGS = 5
MIN_GATE_THRES_TINY = 1
MIN_GATE_THRES_MANY = 3


def np2img(source):

	total = sorted(os.listdir(source))

	hu_imgs = [np.load(os.path.join(source, s)) for s in total]
	gray_imgs = hu2gray(hu_imgs)

	print(f'[INFO]: load {len(gray_imgs)} images from case: {source}\n')

	return gray_imgs


def hu2gray(hu_imgs):
	gray_imgs = []
	for hu in hu_imgs:
		# Turn HU to 0~2550
		hu[hu <= 0] = 0 
		hu[hu >= 2550] = 2550

		# Normalize to 0~1  -> to grayscale 0~255
		hu = hu-np.min(hu)
		hu_range = np.max(hu)-np.min(hu)
		hu = (hu/hu_range)*255
		gray_imgs.append(hu)

	return gray_imgs

def cal_output_total(output):
	frac_num = 0
	for o in output:
		if len(o) > 0:
			frac_num += 1
	return frac_num


def detect_gates(output_adamw, gates):
	if len(output_adamw) <= MIN_IMGS:
		min_gate_thres = MIN_GATE_THRES_TINY
	else:
		min_gate_thres = MIN_GATE_THRES_MANY

	# min gate
	if ('m' in gates) or ('min' in gates) or ('M' in gates) or ('MIN' in gates):
		if cal_output_total(output_adamw) <= min_gate_thres:
			return 0

	if ('c' in gates) or ('con' in gates) or ('C' in gates) or ('CON' in gates):
		output_adamw = consecutive_gate(output_adamw)

	len_adamw = cal_output_total(output_adamw)
	if len_adamw == 0:
		return 0
	else:
		return 1



def detect_gates_ens(output_adamw, output_sgd, gates):
	if len(output_adamw) <= MIN_IMGS:
		min_gate_thres = MIN_GATE_THRES_TINY
	else:
		min_gate_thres = MIN_GATE_THRES_MANY
	
	# min gate
	if ('m' in gates) or ('min' in gates) or ('M' in gates) or ('MIN' in gates):
		min_gate_result = min_gate(output_adamw, output_sgd, min_gate_thres)

		if min_gate_result == 0:
			return 0

	# consecutive gate
	if ('c' in gates) or ('con' in gates) or ('C' in gates) or ('CON' in gates):
		output_adamw = consecutive_gate(output_adamw)
		output_sgd = consecutive_gate(output_sgd)

	# ensemble gate
	ensemble_frac_total = 0
	for a, s in zip(output_adamw, output_sgd):
		if len(a)>0 and len(s)>0:
			ensemble_frac_total += 1

	if ensemble_frac_total == 0:
		return 0
	else:
		return 1


def detect_gates_points(output_adamw, gates):
	if len(output_adamw) <= MIN_IMGS:
		min_gate_thres = MIN_GATE_THRES_TINY
	else:
		min_gate_thres = MIN_GATE_THRES_MANY

	# min gate
	if ('m' in gates) or ('min' in gates) or ('M' in gates) or ('MIN' in gates):
		if cal_output_total(output_adamw) <= min_gate_thres:
			return [[] for _ in output_adamw]

	if ('c' in gates) or ('con' in gates) or ('C' in gates) or ('CON' in gates):
		output_adamw = consecutive_gate(output_adamw)

	len_adamw = cal_output_total(output_adamw)
	if len_adamw == 0:
		return [[] for _ in output_adamw]
	else:
		output = []
		for out in output_adamw:
			if len(out) == 0:
				output.append([])
			else:
				img_out = []
				for o in out:
					img_out.append([int(o[0]), int(o[1])])
				output.append(img_out)
		return output



def detect_gates_ens_points(output_adamw, output_sgd, gates):
	if len(output_adamw) <= MIN_IMGS:
		min_gate_thres = MIN_GATE_THRES_TINY
	else:
		min_gate_thres = MIN_GATE_THRES_MANY
	
	# min gate
	if ('m' in gates) or ('min' in gates) or ('M' in gates) or ('MIN' in gates):
		min_gate_result = min_gate(output_adamw, output_sgd, min_gate_thres)

		if min_gate_result == 0:
			return [[] for _ in output_adamw]

	# consecutive gate
	if ('c' in gates) or ('con' in gates) or ('C' in gates) or ('CON' in gates):
		output_adamw = consecutive_gate(output_adamw)
		output_sgd = consecutive_gate(output_sgd)

	# ensemble gate
	ensemble_frac_total = 0
	for a, s in zip(output_adamw, output_sgd):
		if len(a)>0 and len(s)>0:
			ensemble_frac_total += 1

	if ensemble_frac_total == 0:
		return [[] for _ in output_adamw]
	else:
		output = []
		for out_a, out_s in zip(output_adamw, output_sgd):
			if len(out_a)>0 and len(out_s)>0:
				img_out = []
				for o in out_a:
					img_out.append([int(o[0]), int(o[1])])
				output.append(img_out)
			else:
				output.append([])

		return output


### GATES
def min_gate(output_adamw, output_sgd, threshold):

	len_adamw = cal_output_total(output_adamw)
	len_sgd = cal_output_total(output_sgd)

	if not len_adamw >= threshold and not len_sgd >= threshold:
		return 0

	return 1

def consecutive_gate(output):

	for i in range(len(output)):
		if i == 0:
			if len(output[i+1]) == 0:
				output[i] == output[i+1]
		elif i == len(output)-1:
			if len(output[i-1]) == 0:
				output[i] == output[i-1]
		else:
			if len(output[i-1]) == 0 and len(output[i+1]) == 0:
				if len(output[i-1]) == 0:
					output[i] == output[i-1]
				else:
					output[i] == output[i+1]
	
	return output











