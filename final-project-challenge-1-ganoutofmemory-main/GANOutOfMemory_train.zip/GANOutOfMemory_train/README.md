# DLCV 2021Fall Final Project ( Skull Fractracture Detection )

# TEAM: GANOutOfMemory, members: Cheng-Hsuan Hsieh, Hsin-Yin Chi, Yi-Ting Hung, Tsu-Fu Li, Yu-Chin Tsai

## How to run:
	# preprocess data
	python3 preprocess.py --root <ROOT FOLDER OF TRAIN DATA> --train_json <PATH OF records_train.json> --test_root <ROOT FOLDER OF TEST DATA>
	python3 split_train.py
	# train with AdamW + images-weights
	python3 yolov5/train.py --weights '' --cfg yolov5s_fracture.yaml --data skull.yaml --epochs 100 --batch-size 32 --img 512 --optimizer AdamW --project ./ckpt --name adamw --rect --image-weights
	# train with SGD
	python3 yolov5/train.py --weights '' --cfg yolov5s_fracture.yaml --data skull.yaml --epochs 100 --batch-size 32 --img 512 --optimizer SGD --project ./ckpt --name sgd --rect

### preprocess.py
* split raw data to RGB images and labels
* output: 
	* ./data/records_train.csv (All records of data. Turned from records_train.json)
	* ./data/train_label.csv (Train labels csv)
	* ./data/valid_label.csv (Val labels csv)
	* ./data/images/
		* ./data/images/train (Train imgs in case_id folder)
		* ./data/images/val (Val imgs in case_id folder)
	* ./data/labels/
		* ./data/labels/train (Train labels in case_id folder)
		* ./data/labels/val (Val labels in case_id folder)
	* ./data/test (Test imgs folder)
	

### split_train.py
* split RGB images to train data -> sample no fracture images with 2% probability (--ratio 0.02)
* output: 
	* ./train_data/images
		* ./train_data/images/train (Train imgs folder)
		* ./train_data/images/val (Val imgs folder)
	* ./train_data/labels
		* ./train_data/labels/train (Train labels folder)
		* ./train_data/labels/val (Val labels folder)

### yolov5s_fracture.yaml
model setting of yolov5

### skull.yaml
data path and detect classes setting of yolov5

### model weights path
Using official YOLOv5 to train model, output model and hyper-parameters can be set in ./yolov5/train.py
a. AdamW: ./ckpt/adamw/weights/best.pt
a. SGD: ./ckpt/sgd/weights/best.pt


### training details
* We trained on two GPU(tesla p100) for 100 epochs (3hrs), and official yolov5 can save best model according to validation set.
* It will converge at roughly 50-70 epochs.
* We split train/val for first 90% cases and last 10% cases, it can be random sample cases at preprocess.py (add --random).
