import numpy as np
import os
import matplotlib.pyplot as plt
import argparse
import pandas as pd
import imageio

import random
from PIL import Image
import shutil
import argparse


def copyfile(case_id, imgs_path, labels_path, out_imgs_path_t, out_labels_path_t):

    source_img_path = os.path.join(imgs_path, case_id[:-9], case_id+'.jpg')
    dest_img_path = os.path.join(out_imgs_path_t, case_id+'.jpg')
    shutil.copyfile(source_img_path, dest_img_path)
    
    source_label_path = os.path.join(labels_path, case_id[:-9], case_id+'.txt')
    dest_label_path = os.path.join(out_labels_path_t, case_id+'.txt')
    shutil.copyfile(source_label_path, dest_label_path)


def main(args):

    
    out_imgs_path_t = os.path.join(args.out_path, 'images', 'train')
    out_labels_path_t = os.path.join(args.out_path, 'labels', 'train')

    out_imgs_path_v = os.path.join(args.out_path, 'images', 'val') 
    out_labels_path_v = os.path.join(args.out_path, 'labels', 'val') 

    os.makedirs(out_imgs_path_t, exist_ok=True)
    os.makedirs(out_imgs_path_v, exist_ok=True)
    os.makedirs(out_labels_path_t, exist_ok=True)
    os.makedirs(out_labels_path_v, exist_ok=True)

    df = pd.read_csv(args.train_label_csv)
    for i in range(len(df)):
        case = df.iloc[i]
        if case['label'] == 1:
            case_id = case['id']
            copyfile(case_id, args.train_imgs_path, args.train_labels_path, out_imgs_path_t, out_labels_path_t)

        else:
            if random.random() <= args.ratio:
                case_id = case['id']
                copyfile(case_id, args.train_imgs_path, args.train_labels_path, out_imgs_path_t, out_labels_path_t)


    df = pd.read_csv(args.valid_label_csv)
    for i in range(len(df)):
        case = df.iloc[i]
        case_id = case['id']
        copyfile(case_id, args.valid_imgs_path, args.valid_labels_path, out_imgs_path_v, out_labels_path_v)


def argument():
    parser = argparse.ArgumentParser()
    # path to training data
    parser.add_argument('--out_path', default='./train_data', type=str, help='output path of train/val data')

    parser.add_argument('--train_imgs_path', default='./data/images/train', type=str, help='input imgs path of train')
    parser.add_argument('--train_labels_path', default='./data/labels/train', type=str, help='input labels path of train')
    parser.add_argument('--train_label_csv', default='./data/train_label.csv', type=str, help='input path of train csv')

    parser.add_argument('--valid_imgs_path', default='./data/images/val', type=str, help='input imgs path of valid')
    parser.add_argument('--valid_labels_path', default='./data/labels/val', type=str, help='input labels path of valid')
    parser.add_argument('--valid_label_csv', default='./data/valid_label.csv', type=str, help='input path of valid csv')

    parser.add_argument('--ratio', default=0.02, type=float)



    args = parser.parse_args()
    return args





if __name__ == '__main__':
    args = argument()
    main(args)





